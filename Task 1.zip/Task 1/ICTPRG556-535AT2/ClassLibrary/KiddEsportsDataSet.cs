﻿namespace ClassLibrary
{
}

namespace ClassLibrary
{


    public partial class KiddEsportsDataSet
    {
    }
}
