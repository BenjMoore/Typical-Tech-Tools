﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using ClassLibrary;

namespace ICTPRG430AT2
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void LoginBTN_Click(object sender, EventArgs e)
        {
            string username = UsernameTXTBox.Text.Trim();
            string pass = PasswordTXTBox.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(pass))
            {
                MessageBox.Show("Warning: Username or Password Cannot Be Empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataMapper dataMapper = new DataMapper();
            List<UserDTO> foundUser = dataMapper.FindUser(username, pass);

            if (foundUser.Count == 0)
            {
                MessageBox.Show("Warning: Username or Password Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Log the user in
            AuthenticationManager.Instance.LogIn(username);

            MessageBox.Show("Logged In!!", "Logged In", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Open the main form and close the login form
            ClassLibrary.Menu mainForm = new ClassLibrary.Menu();
         
            this.Close(); // Close the login form
        }
    }
}
