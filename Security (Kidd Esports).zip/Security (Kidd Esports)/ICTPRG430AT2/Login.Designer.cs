﻿namespace ICTPRG430AT2
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UsernameTXT = new System.Windows.Forms.Label();
            this.PasswordTXT = new System.Windows.Forms.Label();
            this.UsernameTXTBox = new System.Windows.Forms.TextBox();
            this.PasswordTXTBox = new System.Windows.Forms.TextBox();
            this.LoginBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // UsernameTXT
            // 
            this.UsernameTXT.AutoSize = true;
            this.UsernameTXT.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UsernameTXT.Location = new System.Drawing.Point(76, 38);
            this.UsernameTXT.Name = "UsernameTXT";
            this.UsernameTXT.Size = new System.Drawing.Size(150, 33);
            this.UsernameTXT.TabIndex = 0;
            this.UsernameTXT.Text = "Username";
            // 
            // PasswordTXT
            // 
            this.PasswordTXT.AutoSize = true;
            this.PasswordTXT.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordTXT.Location = new System.Drawing.Point(83, 146);
            this.PasswordTXT.Name = "PasswordTXT";
            this.PasswordTXT.Size = new System.Drawing.Size(143, 33);
            this.PasswordTXT.TabIndex = 1;
            this.PasswordTXT.Text = "Password";
            // 
            // UsernameTXTBox
            // 
            this.UsernameTXTBox.Location = new System.Drawing.Point(82, 86);
            this.UsernameTXTBox.Name = "UsernameTXTBox";
            this.UsernameTXTBox.Size = new System.Drawing.Size(144, 20);
            this.UsernameTXTBox.TabIndex = 2;
            // 
            // PasswordTXTBox
            // 
            this.PasswordTXTBox.Location = new System.Drawing.Point(82, 197);
            this.PasswordTXTBox.Name = "PasswordTXTBox";
            this.PasswordTXTBox.PasswordChar = '*';
            this.PasswordTXTBox.Size = new System.Drawing.Size(144, 20);
            this.PasswordTXTBox.TabIndex = 3;
            // 
            // LoginBTN
            // 
            this.LoginBTN.Location = new System.Drawing.Point(112, 239);
            this.LoginBTN.Name = "LoginBTN";
            this.LoginBTN.Size = new System.Drawing.Size(75, 23);
            this.LoginBTN.TabIndex = 4;
            this.LoginBTN.Text = "Login";
            this.LoginBTN.UseVisualStyleBackColor = true;
            this.LoginBTN.Click += new System.EventHandler(this.LoginBTN_Click);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(301, 304);
            this.Controls.Add(this.LoginBTN);
            this.Controls.Add(this.PasswordTXTBox);
            this.Controls.Add(this.UsernameTXTBox);
            this.Controls.Add(this.PasswordTXT);
            this.Controls.Add(this.UsernameTXT);
            this.Name = "Login";
            this.Text = "Login";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label UsernameTXT;
        private System.Windows.Forms.Label PasswordTXT;
        private System.Windows.Forms.TextBox UsernameTXTBox;
        private System.Windows.Forms.TextBox PasswordTXTBox;
        private System.Windows.Forms.Button LoginBTN;
    }
}