﻿public class AuthenticationManager
{
    private static AuthenticationManager _instance;
    private bool _isLoggedIn;
    private string _username;

    // Private constructor to prevent instantiation
     public AuthenticationManager()
    {
        _isLoggedIn = false;
        _username = string.Empty;
    }

    public static AuthenticationManager Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = new AuthenticationManager();
            }
            return _instance;
        }
    }

    public bool IsLoggedIn
    {
        get { return _isLoggedIn; }
    }

    public string Username
    {
        get { return _username; }
    }

    public void LogIn(string username)
    {
        _isLoggedIn = true;
        _username = username;
    }

    public void LogOut()
    {
        _isLoggedIn = false;
        _username = string.Empty;
    }
}
