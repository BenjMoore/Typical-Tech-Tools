﻿using System;

public class GameDTO
{
    public string GameName { get; set; }
    public string GameType { get; set; }
    public int ID { get; set; }

}
